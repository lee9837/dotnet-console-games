﻿namespace Checkers;

public enum PieceColor
{
	Black = 1,
	White = 2,
}
