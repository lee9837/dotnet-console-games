﻿public static class Statics
{
	public const PieceColor Black = PieceColor.Black;
	public const PieceColor White = PieceColor.White;
}
